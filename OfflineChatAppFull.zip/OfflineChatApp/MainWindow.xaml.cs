using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace OfflineChatApp
{
    public partial class MainWindow : Window
    {
        private string chatDirectory = @"\\SharedDrive\\ChatRooms";
        private string currentChatRoom = "";
        private string userName = Environment.UserName;
        private DispatcherTimer chatRefreshTimer;

        public MainWindow()
        {
            InitializeComponent();
            Directory.CreateDirectory(chatDirectory);
            LoadChatRooms();

            chatRefreshTimer = new DispatcherTimer();
            chatRefreshTimer.Interval = TimeSpan.FromSeconds(2);
            chatRefreshTimer.Tick += ChatRefreshTimer_Tick;
            chatRefreshTimer.Start();
        }

        private void LoadChatRooms()
        {
            ChatRoomList.Items.Clear();
            foreach (var file in Directory.GetFiles(chatDirectory, "*.txt"))
            {
                ChatRoomList.Items.Add(System.IO.Path.GetFileName(file));
            }
        }

        private void ChatRoomList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ChatRoomList.SelectedItem != null)
            {
                currentChatRoom = System.IO.Path.Combine(chatDirectory, ChatRoomList.SelectedItem.ToString());
                ChatHistory.Text = File.ReadAllText(currentChatRoom);
            }
        }

        private void AddChatRoom_Click(object sender, RoutedEventArgs e)
        {
            var name = "ChatRoom_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
            var path = System.IO.Path.Combine(chatDirectory, name);
            File.WriteAllText(path, $"[{DateTime.Now:yyyy-MM-dd HH:mm}] {userName} created the room.\n");
            LoadChatRooms();
        }

        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void SendMessage()
        {
            if (string.IsNullOrWhiteSpace(currentChatRoom)) return;
            var message = $"[{DateTime.Now:yyyy-MM-dd HH:mm}] {userName}: {MessageBox.Text}\n";
            File.AppendAllText(currentChatRoom, message);
            ChatHistory.Text = File.ReadAllText(currentChatRoom);
            MessageBox.Clear();
        }

        private void ChatRefreshTimer_Tick(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(currentChatRoom) && File.Exists(currentChatRoom))
            {
                ChatHistory.Text = File.ReadAllText(currentChatRoom);
            }
        }

        private void MessageBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                SendMessage();
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && MessageBox.IsFocused)
            {
                e.Handled = true;
                SendMessage();
            }
        }
    }
}
