using System.Windows;

namespace OfflineChatApp
{
    public partial class App : Application
    {
    }
}
