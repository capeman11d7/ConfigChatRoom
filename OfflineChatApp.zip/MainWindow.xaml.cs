using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace OfflineChatApp
{
    public partial class MainWindow : Window
    {
        private string chatDirectory = @"\\SharedDrive\\ChatRooms"; // <-- CHANGE TO YOUR ACTUAL SHARED PATH
        private string currentChatRoom = "";
        private string userName = Environment.UserName;

        public MainWindow()
        {
            InitializeComponent();
            Directory.CreateDirectory(chatDirectory);
            LoadChatRooms();
        }

        private void LoadChatRooms()
        {
            ChatRoomList.Items.Clear();
            foreach (var file in Directory.GetFiles(chatDirectory, "*.txt"))
            {
                ChatRoomList.Items.Add(System.IO.Path.GetFileName(file));
            }
        }

        private void ChatRoomList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ChatRoomList.SelectedItem != null)
            {
                currentChatRoom = System.IO.Path.Combine(chatDirectory, ChatRoomList.SelectedItem.ToString());
                ChatHistory.Text = File.ReadAllText(currentChatRoom);
            }
        }

        private void AddChatRoom_Click(object sender, RoutedEventArgs e)
        {
            var name = "ChatRoom_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
            var path = System.IO.Path.Combine(chatDirectory, name);
            File.WriteAllText(path, $"[{DateTime.Now:HH:mm}] {userName} created the room.\n");
            LoadChatRooms();
        }

        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(currentChatRoom)) return;
            var message = $"[{DateTime.Now:HH:mm}] {userName}: {MessageBox.Text}\n";
            File.AppendAllText(currentChatRoom, message);
            ChatHistory.Text = File.ReadAllText(currentChatRoom);
            MessageBox.Clear();
        }
    }
}
