using System.Windows;

namespace ChatAboutIt
{
    public partial class App : Application
    {
    }
}
