using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ChatAboutIt")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ChatAboutIt")]
[assembly: ComVisible(false)]
[assembly: Guid("d1b39c4c-cf1f-4c55-94d6-f148b1d3fbee")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
